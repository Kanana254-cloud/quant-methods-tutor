import streamlit as st
import random
import sqlite3

# Connect to SQLite database
conn = sqlite3.connect('student_progress.db')
c = conn.cursor()
c.execute("""
    CREATE TABLE IF NOT EXISTS progress (
        name TEXT,
        topic TEXT,
        correct INTEGER,
        attempts INTEGER
    )
""")
conn.commit()

# Sample domain content: Quantitative Methods
questions = {
    "Descriptive Statistics": [
        {
            "question": "What is the mean of 5, 10, 15, and 20?",
            "answer": 12.5,
            "hint": "Add all numbers and divide by the count."
        },
        {
            "question": "What is the median of 3, 7, 9, 12, and 15?",
            "answer": 9,
            "hint": "The median is the middle number when arranged in order."
        }
    ],
    "Probability Theory": [
        {
            "question": "If P(A) = 0.3 and P(B) = 0.5, what is P(A and B) assuming independence?",
            "answer": 0.15,
            "hint": "Use: P(A and B) = P(A) * P(B)"
        },
        {
            "question": "What is the probability of getting a 3 on a fair six-sided die?",
            "answer": 1/6,
            "hint": "There is 1 favorable outcome out of 6."
        }
    ],
    "Linear Programming": [
        {
            "question": "What type of problem does Linear Programming solve?",
            "answer": "optimization",
            "hint": "It finds the best value given constraints."
        },
        {
            "question": "If the objective is to maximize profit, what kind of function is used?",
            "answer": "objective function",
            "hint": "It's the main function being optimized."
        }
    ],
    "Hypothesis Testing": [
        {
            "question": "What is the null hypothesis typically denoted as?",
            "answer": "H0",
            "hint": "It's the hypothesis we try to disprove."
        },
        {
            "question": "A p-value less than 0.05 indicates what?",
            "answer": "reject null",
            "hint": "It's about statistical significance."
        }
    ]
}

st.set_page_config(page_title="Quantitative Methods Tutor Bot")
st.title("📊 Quantitative Methods Tutor Bot")

# Get student name
student_name = st.text_input("Enter your name to track your progress")

if student_name:
    # Choose a topic
    topic = st.selectbox("Choose a Topic", list(questions.keys()))
    question_data = random.choice(questions[topic])

    st.write("**Question:**", question_data["question"])
    user_answer = st.text_input("Your Answer")

    if st.button("Check Answer"):
        correct = False
        try:
            if isinstance(question_data["answer"], (int, float)):
                correct = abs(float(user_answer) - float(question_data["answer"])) < 0.001
            else:
                correct = user_answer.strip().lower() == str(question_data["answer"]).lower()
        except:
            correct = False

        # Update database
        c.execute("SELECT * FROM progress WHERE name = ? AND topic = ?", (student_name, topic))
        row = c.fetchone()
        if row:
            new_correct = row[2] + (1 if correct else 0)
            new_attempts = row[3] + 1
            c.execute("UPDATE progress SET correct = ?, attempts = ? WHERE name = ? AND topic = ?",
                      (new_correct, new_attempts, student_name, topic))
        else:
            c.execute("INSERT INTO progress (name, topic, correct, attempts) VALUES (?, ?, ?, ?)",
                      (student_name, topic, 1 if correct else 0, 1))
        conn.commit()

        if correct:
            st.success("Correct! 🎉 Well done.")
        else:
            st.error("Oops! That's not quite right.")
            if st.button("Show Hint"):
                st.info(question_data["hint"])

    # Show progress
    if st.checkbox("Show My Progress"):
        c.execute("SELECT topic, correct, attempts FROM progress WHERE name = ?", (student_name,))
        data = c.fetchall()
        for row in data:
            topic_name, correct, attempts = row
            accuracy = (correct / attempts * 100) if attempts else 0
            st.write(f"**{topic_name}** — {correct} correct out of {attempts} attempts ({accuracy:.1f}% accuracy)")
